#!/usr/bin/env python3
"""
Учёт техники в магазинах (телевизоров) — AI-система детекции на YOLOv8
Практика (Системы искусственного интеллекта), МТУСИ
"""

import os
import json
import uuid
from datetime import datetime

import cv2
import numpy as np
from flask import Flask, request, jsonify, render_template, send_file, url_for
from ultralytics import YOLO
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.lib.utils import ImageReader
import openpyxl
from io import BytesIO

app = Flask(__name__)

# Конфигурация
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['STATIC_FOLDER'] = 'static'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB

# Создаём папки, если их нет
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['STATIC_FOLDER'], exist_ok=True)

# Загружаем предобученную модель YOLOv8n
# Для детекции телевизоров будем фильтровать по классу "TV" (class 62 в COCO)
print("Загрузка модели YOLOv8n...")
model = YOLO('yolov8n.pt')
print("Модель загружена успешно!")

# ID класса "TV monitor" в COCO — 62
TV_CLASS_ID = 62
CLASS_NAMES = {0: 'person', 1: 'bicycle', 2: 'car', 3: 'motorcycle', 4: 'airplane',
               5: 'bus', 6: 'train', 7: 'truck', 8: 'boat', 9: 'traffic light',
               10: 'fire hydrant', 11: 'stop sign', 12: 'parking meter', 13: 'bench',
               14: 'bird', 15: 'cat', 16: 'dog', 17: 'horse', 18: 'sheep', 19: 'cow',
               20: 'elephant', 21: 'bear', 22: 'zebra', 23: 'giraffe', 24: 'backpack',
               25: 'umbrella', 26: 'handbag', 27: 'tie', 28: 'suitcase', 29: 'frisbee',
               30: 'skis', 31: 'snowboard', 32: 'sports ball', 33: 'kite', 34: 'baseball bat',
               35: 'baseball glove', 36: 'skateboard', 37: 'surfboard', 38: 'tennis racket',
               39: 'bottle', 40: 'wine glass', 41: 'cup', 42: 'fork', 43: 'knife',
               44: 'spoon', 45: 'bowl', 46: 'banana', 47: 'apple', 48: 'sandwich',
               49: 'orange', 50: 'broccoli', 51: 'carrot', 52: 'hot dog', 53: 'pizza',
               54: 'donut', 55: 'cake', 56: 'chair', 57: 'couch', 58: 'potted plant',
               59: 'bed', 60: 'dining table', 61: 'toilet', 62: 'tv', 63: 'laptop',
               64: 'mouse', 65: 'remote', 66: 'keyboard', 67: 'cell phone', 68: 'microwave',
               69: 'oven', 70: 'toaster', 71: 'sink', 72: 'refrigerator', 73: 'book',
               74: 'clock', 75: 'vase', 76: 'scissors', 77: 'teddy bear', 78: 'hair drier',
               79: 'toothbrush'}


# ---------- Инициализация SQLite ----------
import sqlite3

def init_db():
    conn = sqlite3.connect('history.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            request_id TEXT UNIQUE,
            filename TEXT,
            timestamp TEXT,
            tv_count INTEGER,
            confidence_avg REAL,
            image_width INTEGER,
            image_height INTEGER,
            result_image TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()


# ---------- Вспомогательные функции ----------

def allowed_file(filename):
    """Проверка расширения файла."""
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'bmp'}
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_to_history(req_id, filename, tv_count, conf_avg, w, h, result_path):
    """Сохраняет результат обработки в историю (SQLite)."""
    conn = sqlite3.connect('history.db')
    cursor = conn.cursor()
    cursor.execute(
        'INSERT OR REPLACE INTO requests (request_id, filename, timestamp, tv_count, confidence_avg, image_width, image_height, result_image) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        (req_id, filename, datetime.now().isoformat(), tv_count, conf_avg, w, h, result_path)
    )
    conn.commit()
    conn.close()


def get_history():
    """Возвращает историю запросов."""
    conn = sqlite3.connect('history.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM requests ORDER BY timestamp DESC')
    rows = cursor.fetchall()
    conn.close()
    return rows


# ---------- Маршруты ----------

@app.route('/')
def index():
    """Главная страница."""
    return render_template('index.html')


@app.route('/process', methods=['POST'])
def process_image():
    """Обработка изображения — детекция телевизоров."""
    if 'image' not in request.files:
        return jsonify({'error': 'Файл не загружен'}), 400

    file = request.files['image']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Неверный формат файла. Используйте PNG, JPG, JPEG, WEBP или BMP'}), 400

    # Генерируем уникальный ID запроса
    req_id = str(uuid.uuid4())[:8]
    ext = file.filename.rsplit('.', 1)[1].lower()

    # Сохраняем оригинал
    orig_filename = f"{req_id}_original.{ext}"
    orig_path = os.path.join(app.config['UPLOAD_FOLDER'], orig_filename)
    file.save(orig_path)

    # Читаем изображение
    img = cv2.imread(orig_path)
    if img is None:
        return jsonify({'error': 'Не удалось прочитать изображение'}), 400

    h_img, w_img = img.shape[:2]

    # Прогоняем через YOLOv8
    results = model(img)

    # Фильтруем только телевизоры (class 62)
    tv_count = 0
    confidences = []
    boxes_data = []

    if results[0].boxes is not None:
        for box in results[0].boxes:
            cls_id = int(box.cls[0])
            conf = float(box.conf[0])
            if cls_id == TV_CLASS_ID:
                tv_count += 1
                confidences.append(conf)
                x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                boxes_data.append({
                    'x1': x1, 'y1': y1, 'x2': x2, 'y2': y2,
                    'confidence': round(conf, 3)
                })

    confidence_avg = round(float(np.mean(confidences)), 3) if confidences else 0.0

    # Визуализируем — рисуем все bounding boxes для телевизоров
    result_img = img.copy()
    for b in boxes_data:
        color = (0, 255, 0)  # зелёный
        cv2.rectangle(result_img, (b['x1'], b['y1']), (b['x2'], b['y2']), color, 3)
        label = f"TV {b['confidence']:.2f}"
        # Фон для текста
        (tw, th), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
        cv2.rectangle(result_img, (b['x1'], b['y1'] - th - 10), (b['x1'] + tw + 10, b['y1']), color, -1)
        cv2.putText(result_img, label, (b['x1'] + 5, b['y1'] - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 2)

    # Если TV не найдены — выводим сообщение на изображении
    if tv_count == 0:
        cv2.putText(result_img, "Телевизоры не обнаружены", (30, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 0, 255), 3)

    # Сохраняем результат
    result_filename = f"{req_id}_result.{ext}"
    result_path = os.path.join(app.config['STATIC_FOLDER'], result_filename)
    cv2.imwrite(result_path, result_img)

    # Сохраняем в историю
    save_to_history(req_id, file.filename, tv_count, confidence_avg, w_img, h_img, result_filename)

    return jsonify({
        'request_id': req_id,
        'tv_count': tv_count,
        'confidence_avg': confidence_avg,
        'image_width': w_img,
        'image_height': h_img,
        'result_image': url_for('static', filename=result_filename),
        'boxes': boxes_data
    })


@app.route('/history')
def history():
    """Страница истории запросов."""
    rows = get_history()
    return render_template('history.html', history=rows)


@app.route('/history/data')
def history_data():
    """API истории в JSON."""
    rows = get_history()
    data = []
    for row in rows:
        data.append({
            'id': row[0],
            'request_id': row[1],
            'filename': row[2],
            'timestamp': row[3],
            'tv_count': row[4],
            'confidence_avg': row[5],
            'image_width': row[6],
            'image_height': row[7],
            'result_image': url_for('static', filename=row[8]) if row[8] else None
        })
    return jsonify(data)


@app.route('/report/pdf')
def generate_pdf():
    """Генерация PDF-отчёта по истории обработок."""
    rows = get_history()
    if not rows:
        return jsonify({'error': 'Нет данных для отчёта'}), 400

    buffer = BytesIO()
    c = pdf_canvas.Canvas(buffer, pagesize=A4)
    width, height = A4

    # Заголовок
    c.setFont("Helvetica-Bold", 16)
    c.drawString(50, height - 50, "Отчёт по детекции телевизоров")
    c.setFont("Helvetica", 10)
    c.drawString(50, height - 70, f"Сгенерирован: {datetime.now().strftime('%d.%m.%Y %H:%M')}")
    c.drawString(50, height - 85, f"Всего обработано изображений: {len(rows)}")
    total_tvs = sum(r[4] for r in rows)
    c.drawString(50, height - 100, f"Всего обнаружено телевизоров: {total_tvs}")

    # Таблица
    y = height - 130
    c.setFont("Helvetica-Bold", 9)
    c.drawString(30, y, "ID")
    c.drawString(70, y, "Файл")
    c.drawString(200, y, "Дата")
    c.drawString(320, y, "TV найдено")
    c.drawString(410, y, "Ср. уверенность")
    y -= 15
    c.setFont("Helvetica", 8)

    # Если есть изображение — вставим последний результат
    if rows:
        last = rows[0]
        last_img_path = os.path.join(app.config['STATIC_FOLDER'], last[8])
        if os.path.exists(last_img_path):
            try:
                c.drawString(50, y - 20, "Последний результат обработки:")
                c.drawImage(ImageReader(last_img_path), 50, y - 250, width=400, height=200, preserveAspectRatio=True)
                y -= 260
            except Exception:
                pass

    for row in rows:
        c.drawString(30, y, str(row[1]))
        c.drawString(70, y, row[2][:20])
        c.drawString(200, y, row[3][:16])
        c.drawString(330, y, str(row[4]))
        c.drawString(420, y, str(row[5]))
        y -= 14
        if y < 50:
            c.showPage()
            y = height - 50
            c.setFont("Helvetica", 8)

    c.save()
    buffer.seek(0)
    return send_file(buffer, mimetype='application/pdf', as_attachment=True,
                     download_name=f'report_{datetime.now().strftime("%Y%m%d_%H%M")}.pdf')


@app.route('/report/excel')
def generate_excel():
    """Генерация Excel-отчёта по истории обработок."""
    rows = get_history()
    if not rows:
        return jsonify({'error': 'Нет данных для отчёта'}), 400

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "История детекции телевизоров"

    # Заголовки
    headers = ['ID запроса', 'Имя файла', 'Дата', 'TV найдено', 'Ср. уверенность',
               'Ширина', 'Высота']
    ws.append(headers)

    for row in rows:
        ws.append([row[1], row[2], row[3], row[4], row[5], row[6], row[7]])

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return send_file(buffer, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True,
                     download_name=f'report_{datetime.now().strftime("%Y%m%d_%H%M")}.xlsx')


@app.route('/stats')
def stats():
    """API статистики по всем обработкам."""
    rows = get_history()
    if not rows:
        return jsonify({'total_requests': 0, 'total_tvs': 0, 'avg_confidence': 0})

    total_requests = len(rows)
    total_tvs = sum(r[4] for r in rows)
    confs = [r[5] for r in rows if r[5] > 0]
    avg_conf = round(float(np.mean(confs)), 3) if confs else 0

    return jsonify({
        'total_requests': total_requests,
        'total_tvs': total_tvs,
        'avg_confidence': avg_conf,
        'avg_tvs_per_image': round(total_tvs / total_requests, 2) if total_requests else 0
    })


if __name__ == '__main__':
    print("=" * 60)
    print("Запуск сервера детекции телевизоров (YOLOv8)")
    print("Локальный доступ: http://127.0.0.1:5000")
    print("=" * 60)
    app.run(host='0.0.0.0', port=5000, debug=True)